# July 11, 2022 Release Notes - 2.3.6
1. [Cloud Guard Events](#2-3-6-cg-events)
1. [Updated Logging Architecture](#2-3-6-updated-logging)
1. [Terraform OCI Provider Moved to oracle/oci](#2-3-6-provider-switch)
1. [Architecture Center Tag](#2-3-6-arch-center-tag)
1. [CIS Compliance Checking Script Update](#2-3-6-cis-script-update)

## <a name="2-3-6-cg-events">Cloud Guard Events</a>
Cloud Guard events have been added to Landing Zone notifications framework. Now users can be notified about Cloud Guard problems that exceeds a user provided criticality threshold.  To support this two new variables have been added to the Cloud Guard Section: `cloud_guard_risk_level_threshold` and `cloud_guard_admin_email_endpoints`. The risk_level_threshold determines what problems will trigger the event rule and send an email to the subscription in the new topic. A level of 'High' will include any problems with a risk level of High or above. This would include High and Critical problems. The event rule looks at any of the 3 Cloud Guard events: Problem Detected, Problem Dismissed and Problem Remediated.

## <a name="2-3-6-updated-logging">Updated Logging Architecture</a>
The [Service Connector Hub module](./config/mon_service_connector.tf) has been updated to align with the [best practice architecture for third-party SIEM tools](https://github.com/oracle-quickstart/oci-arch-logging-splunk).
Now there is a single Landing Zone Service Connector that ingests three log sources (Audit logs, VCN flow logs and Object Storage logs) into a target resource of choice: Object Storage Bucket, Stream or Function.
Landing Zone creates the Bucket and can either create the Stream or use an existing one. If a Function is the target, it must be provided as an input.

## <a name="2-3-6-provider-switch">Terraform OCI Provider Moved to oracle/oci</a>
Landing Zone has been updated with the new home for Terraform OCI provider. It has moved to oracle/oci from hashicorp/oci. 
- Existing Landing Zone customers who use Terraform CLI are required to replace the provider in the state file. To update the state file, run the command below in the folder where the state file is present:

        > terraform state replace-provider hashicorp/oci oracle/oci

- Existing Landing Zone customers who use OCI Resource Manager do not need to do anything, as Resource Manager will update the state file based on the new Landing Zone configuration. 

As part of this move, we have introduced provider requirements expressed in [provider.tf](./config/provider.tf):
- Terraform required version >= 1.0.0
- OCI provider version >= 4.78.0

## <a name="2-3-6-arch-center-tag">Architecture Center Tag</a>
A [defined tag](./config/mon_tags.tf) to track Landing Zone deployments through [OCI Architecture Center](https://docs.oracle.com/solutions/) has been added.

## <a name="2-3-6-cis-script-update">CIS Compliance Checking Script Update</a>
The CIS Compliance checking script now consolidates regional output.  There is a single directory which contains the summary report and findings reports in a directory, the name includes the tenancy name and datetime ex. `<tenancy-name>-2022-MM-DD_HH-MM/`.  The findings CSV in that directory now have a region column to tell you which region the resource is located. 

In addition two new flags have been added:
- `--region` - pass an OCI region name(s) ex. `--region us-ashburn-1,eu-frankfurt-1` and the script will check that region's resources for CIS compliance 
- `--raw` - will output all OCI resource data collected into CSV files with the OCI Service name 

For more details on these flags [compliance-script.md](./compliance-script.md)

# June 13, 2022 Release Notes - Stable 2.3.5
1. [CIS Compliance Checking Script 1.2 update](#2-3-5-script-update)
1. [CIS 1.2 OCI IAM Policy Updates and Storage Admin](#2-3-5-storage_admin)
1. [Connectivity Section Usability Improvements in Resource Manager](#2-3-5-conn_usage)
1. [Removed Public RDP Access](#2-3-5-rdp-public-removal)


## <a name="2-3-5-script-update">CIS Compliance Checking Script 1.2 update</a>
The CIS reports script ([cis_reports.py](./scripts/cis_reports.py)) has been updated to check a tenancy’s compliance with the [CIS OCI Foundations Benchmark 1.2.0]( https://www.cisecurity.org/benchmark/oracle_cloud).  In addition to the new compliance checks, we have streamlined the checks in non-home regions to exclude the IAM since it is redundant.  We also added a new flag `--level` which allows you to run all the CIS OCI Foundations Benchmark 1.2 checks or only those checks associated with Level 1.  The [documentation](./compliance-script.md) for the CIS reports script has been updated to reflect this release.

You can learn about what was added to version 1.2 of the benchmark [here](https://www.ateam-oracle.com/post/the-center-for-internet-security-oracle-cloud-infrastructure-foundations-benchmark-12-release-update). 


## <a name="2-3-5-storage_admin">CIS 1.2 OCI IAM Policy Updates and Storage Admin</a>
We have introduced a group for storage management, entitled to delete OCI storage resources across Landing Zone compartments. The feature implements the recommendation 1.14 of CIS OCI Foundations Benchmark v1.2.0 that states *Ensure storage service-level admins cannot delete resources they manage*, ensuring segregation of duties from service-level administrators, who cannot delete resources they are managing.

Our recommendation for using this group is to place users in it when they must delete an OCI storage resource and then remove their access once that resource is deleted.

In addition we reviewed our policy for consistency.

## <a name="2-3-5-conn_usage">Connectivity Section Usability Improvements</a>
The *Connectivity* variables group in [schema.yml](./config/schema.yml) for OCI Resource Manager UI have been split for improved usability. Now we have separate sections for Hub/Spoke, Public Connectivity, Connectivity to on-premises and DRG. Some section titles and variables descriptions have also been updated.

## <a name="2-3-5-rdp-public-removal">Removed Public RDP Access</a>
We no longer grant RDP access to the bastion NSGs for `public_src_bastion_cidrs` CIDR addresses thus preventing public access to RDP.

# May 11, 2022 Release Notes - Stable 2.3.4
1. [Configurable Cloud Guard Alerting](#cg_alerting)
1. [Advanced Options Check Preservation in Resource Manager](#orm_adv_options)
1. [Notification Endpoints not Required by CIS Not Shown By Default](#hidden_endpoints)
1. [ExaCS VCN Route Table Fix](#exacs_vcn_rt_fix)

## <a name="cg_alerting">Configurable Cloud Guard Alerting based on Problem Risk Level</a>
Cloud Guard Alerting can optionally be configured by the Landing Zone. Two new variables have been added to the Cloud Guard Section: cloud_guard_risk_level_threshold and cloud_guard_admin_email_endpoints. A new topic and new Event rule will be created only if a valid Email Endpoint is provided. The risk_level_threshold determines what problems will trigger the event rule and send an email to the subscription in the new topic. A level of 'High' will include any problems with a risk level of High or above. This would include High and Critical problems. The event rule looks at any of the 3 Cloud Guard events: Problem Detected, Problem Dismissed and Problem Remediated.

## <a name="orm_adv_options">Advanced Options Check Preservation for Resource Manager</a>
CIS Landing Zone interface for Resource Manager has check boxes allowing for advanced input options, hiding or showing groups of variables. The state of these options used to be reset when users needed to update the variables in the UI, hiding options chosen previously. Now the state is saved and no longer reset. Changes made in [config/variables.tf](./config/variables.tf).

## <a name="hidden_endpoints">Notification Endpoints not Required by CIS Not Displayed By Default</a>
Except for Security and Network notifications, all other endpoints are no longer displayed by default in [config/schema.yml](./config/schema.yml) for OCI Resource Manager. A new _Additional Notification Endpoints_ check box displays them when checked. 

## <a name="exacs_vcn_rt_fix">ExaCS VCN Route Table Fix</a>
A fix in the [route table of the Client subnet](./config/net_exacs_vcns.tf) allows for proper on-premises routing with or without a DMZ VCN. If a DMZ VCN is deployed, traffic to an on-premises IP address goes through the VCN. Otherwise, traffic goes to on-premises directly through the DRG.

# April 6, 2022 Release Notes - Stable 2.3.3
1. [Cloud Guard Updates](#cg_updates)
1. [VSS Policy Update](#vss_update)
1. [Code Examples Aligned with Deployment Guide](#code_examples)

## <a name="cg_updates">Cloud Guard Updates</a>
- [Cloud Guard policy](./config/iam_service_policies.tf) has been simplified with *Allow service cloudguard to read all-resources in tenancy*. This way no policy changes are needed as new services are integrated with Cloud Guard.
- [Cloud Guard enablement](./config/mon_cloud_guard.tf) and [target creation logic](./modules/monitoring/cloud-guard/main.tf) have been updated, but still based on *cloud_guard_configuration_status* variable. When the variable is set to 'ENABLE', Cloud Guard is enabled and a target is created for the Root compartment. **Customers need to make sure there is no pre-existing Cloud Guard target for the Root compartment or target creation will fail**. If there is a **pre-existing** Cloud Guard target for the Root compartment, set the variable to 'DISABLE'. In this case, any **pre-existing** Cloud Guard Root target is left intact. However, keep in mind that once you set the variable to 'ENABLE', Cloud Guard Root target becomes managed by Landing Zone. If later on you switch to 'DISABLE', Cloud Guard remains enabled but the Root target is deleted.

## <a name="vss_update">VSS Policy Update</a>
[Policy update](./config/iam_service_policies.tf) allowing Vulnerability Scanning Service (VSS) to scan containers in OCI Registry: *Allow service vulnerability-scanning-service to read repos in tenancy*.

## <a name="code_examples">Code Examples Aligned with Deployment Guide</a>
An [examples](./examples/) folder has been added showcasing input variables for the various deployment samples provided in the [deployment guide](DEPLOYMENT-GUIDE.md). The examples follow Oracle documentation guidelines for acceptable company name.

# March 18, 2022 Release Notes - Stable 2.3.2
1. [Deployment Guide](#deployment_guide)
1. [Reviewed IAM Admin Policies](#iam_policies_review)

## <a name="deployment_guide">Deployment Guide</a>
A compreehensive [deployment guide](DEPLOYMENT-GUIDE.md) for CIS Landing Zone is now available. It covers key deployment considerations, the architecture, major deployment scenarios, customization guidance, detailed steps how to deploy using Terraform CLI and with Resource Manager UI/CLI as well as various deployment configuration samples.

## <a name="iam_policies_review">Reviewed IAM Admin Policies</a>
IAM admin policy has been updated to not allow IAM administrators to manage compartments and policies at the Root compartment, thus avoiding privilege escalation.

# February 25, 2022 Release Notes - Stable 2.3.1
1. [Configurable Spoke Subnet Names and Subnet Sizes](#spoke_config)
1. [Updated Compute Dynamic Group to support OS Management](#dg_osms)
1. [Fixed Internet Gateway Creation in ExaCS VCN](#exacs_fix)
1. [Updated Bastion NSG to include RDP](#rdp_update)
1. [Tagging Support](#tagging)

## <a name="spoke_config">Configurable Spoke Subnet Names and Subnet Sizes</a>
The names and the size of subnets created in spoke VCN(s) can now be configured using the variables: **subnets_names** and **subnets_sizes**. Ex. `["front", "middle", "back"]` and `["12","8","10"]`.  Additional customization of spoke VCNs can be done in net_vcn.tf or with  using [Terraform Override Files](https://www.terraform.io/language/files/override).
Check [Known Issues](README.md#know-issues) section for an issue affecting custom subnets sizes in Resource Manager UI.

## <a name="dg_osms">Updated Compute Dynamic Group to support OS Management</a>
Added IAM policy statements to the compute agent dynamic group policy to include support for OS Management.

## <a name="exacs_fix">Fixed Internet Gateway Creation in ExaCS VCN</a>
Disabled creation of Internet Gateway in ExaCS VCNs.

## <a name="rdp_update">Updated Bastion NSG to include RDP</a>
Added port 3389 to the Bastion Network Security Group (NSG) to support Remote Desktop Protocol (RDP) for Windows based instances.

## <a name="tagging">Tagging Support</a>
The Landing Zone fully supports definition and usage of defined_tags and freeform_tags for all resources. In this release there is no additional variable to be set in the quickstart-input.tfvars. Tag definition and usage can be set using [Terraform Override Files](https://www.terraform.io/language/files/override).

Usage Overview:
- Defined tags - At the moment, using Defined Tags is a two step process.
  1. Create the defined tags.
  1. Use the defined tags.
- Freeform tags - Freeform tags can be used at any time. You simply assign a map of freeform tags, to a predefined local variable in an override file, for example ```all_keys_freeform_tags = {"cis-landing-zone" : "${var.service_label}-quickstart"}```.

Please note that space characters (' ') in the tag names are not supported by OCI.

# February 02, 2022 Release Notes - Stable 2.3.0
1. [Cross Region Landing Zone](#cross_region_lz_2_3_0)
1. [Bring Existing Dynamic Groups](#byodg_2_3_0)
1. [CCCS Guard Rails](#script_2_3_0)
1. [Landing Zone Logo](#lz_logo_2_3_0)
1. [Customized VCN and Subnet deployment option](#lz_vcn_2_3_0)

## <a name="cross_region_lz_2_3_0">Cross Region Landing Zone</a>
When you run Landing Zone's Terraform, some resources are created in the home region, while others are created in a region of choice. Among home region resources are compartments, groups, dynamic groups, policies, tag defaults and an infrastructure for IAM related notifications (including events, topics and subscriptions). Among resources created in the region of choice are VCNs, Log Groups, and those pertaining to security services like Vault Service, Vulnerability Scanning, Service Connector Hub, Bastion. The home region resources are automatically made available by OCI in all subscribed regions.

Some customers want to extend their Landing Zone to more than one region of choice, while reusing the home region resources. One typical use case is setting up a second region of choice for disaster recovery, reusing the same home region Landing Zone resources. A more broad use case is implementing a single global Landing Zone across all subscribed regions. These use cases are now supported via the newly introduced *extend_landing_zone_to_new_region*. When set to true, compartments, groups, dynamic groups, policies and resources pertaining to home region are not provisioned, but reused instead.

## <a name="byodg_2_3_0">Bring Existing Dynamic Groups</a>
As with groups, Landing Zone now supports reusing existing *dynamic* groups. These dynamic groups are thought to be used by OCI Functions, Compute's management agent and databases for calling out other services. 

## <a name="script_2_3_0">CCCS Guard Rails</a>
The Compliance Checking script's summary report now includes a column for CCCS Guard Rails.

## <a name="lz_logo_2_3_0">Landing Zone Logo</a>
Landing Zone has been gifted with a logo. A courtesy from our colleague [Chris Johnson](https://github.com/therealcmj).   

## <a name="lz_vcn_2_3_0">Customized VCN and Subnet deployment option</a>
This release provides the option to easily customize your VCNs and Subnets in terms of cidr ranges and naming using a map resource called custom_vcns_map.
Please note as part of this release we have also updated the default Database subnet to include a routing rule for sending traffic destined for 0.0.0.0/0 to the NAT Gateway.
However the default Network Security Group will still prevent any egress to the internet until it is changed by you.


# December 02, 2021 Release Notes - Stable 2.2.0
1. [Updated Topics and Subscription Module (Impacts existing deployments)](#topics_2_2_0)
1. [Enablement of Operational Events and Alarms Specific to Compute, Storage, Database and Governance](#events_and_alarms_2_2_0)
1. [Compliance Checking Script Runs in All Regions](#script_update_2_2_0)
1. [Click to Deploy button](#click_to_deploy_2_2_0)
1. [Added SVG versions of Core Architecture Files](#svg_architecture_files)
1. [Added an optional Budget and Budget Alert Rule](#budget_2_2_0)


## <a name="topics_2_2_0">Updated Topics and Subscription Module (Impacts existing deployments)</a>
In previous versions of the Landing Zone Topics and Subscriptions were a single module.  Going forward there will be a [Topics Module](modules/topics-v2/toopics/README.md) and a [Subscription Module](modules/topics-v2/subscriptions/README.md). **Due to this change upgrading an existing Landing Zone deployment will cause the Security Topic and Subscriptions as well as the Network Topic and Subscriptions to be deleted and recreated.** This will require users receiving these email notifications to re-accept their subscriptions.

## <a name="events_and_alarms_2_2_0">Enablement of Operational Events and Alarms Specific to Compute, Storage, Database and Governance</a>
Customers can now deploy events and alarms specific to operational areas including Compute, Storage, Database and Governance as part of the default Landing Zone deployment. Operational alarms and events can be enabled by entering an email address in. This includes following alarms:
- AppDev Compartment
    - Instance based monitoring and alerting of high cpu and high memory usage for instances deployed in the AppDev compartment.
    - Bare metal unhealthy and VM maintenance alarms are also part of the new core compute alarm set.
- Database Compartment 
    - Databases deployed in the Database compartment operational events and alerts have been enabled for for high ADB CPU and high ADB Storage usage.
    - Autonomous Database Critical Events and ExaData CS Infrastructure events are now tracked in this release.
- Network Compartment
    - Up/Down status for VPN and FastConnect services in the Network compartment of the Landing Zone.

## <a name="script_update_2_2_0">Compliance Checking Script Runs in All Regions</a>
The compliance checking script now runs checks on all available regions in the tenancy and has improved handling of Oracle PSM policy statements.

## <a name="click_to_deploy_2_2_0">Click to Deploy button</a>
Resource Manager stack can be created directly from GitHub repository through a single button click. The zip file with the source code is passed directly to Resource Manager Create Stack API. 

## <a name="svg_architecture_files">Added SVG versions of Core Architecture Files</a>
Added SVG versions of Core Architecture Files so users can modify the architectures using Draw.io.

## <a name="budget_2_2_0">Added an optional Budget and Budget Alert Rule</a>
Customers can now choose to deploy a budget at the root or enclosing compartment level to track monthly spending and be alerted if a forcasted spending breaches a defined threshold. 

A Cost Managment Admin group is also created that grants permission to Create,Update,Delete budgets and also review Cost Data in the UI or by downloading the detailed Cost Reports.
Cost Data View Only permissions have been added to the policies for: Auditor, Database Admin, AppDev Admin, Network Admin and Security Admin allowing members of these groups to review spending. 
  
# October 13, 2021 Release Notes - Stable 2.1.1
1. [CIS Compliance Checking Script Updates](#cis_script_2_1_1)
1. [Bastion Service Enabled by public_src_bastion_cidrs](#bastion_service_update)

## <a name="cis_script_2_1_1">CIS Compliance Checking Script Updates</a>
CIS Compliance checking script will now prepend the OCI tenancy's display name to the output directory it creates if no directory is specified.  An example output directory `tenancy_display_name-20211013`.

## <a name="bastion_service_update">Bastion Service Enabled by public_src_bastion_cidrs</a>
Now [OCI Bastion service] (https://docs.oracle.com/en-us/iaas/Content/Bastion/Concepts/bastionoverview.htm) is enabled when one or more *public_src_bastion_cidrs* are provided **and** a single VCN deployment is selected.  In the previous version it was enabled by default in a single VCN deployment.

# September 24, 2021 Release Notes - Stable 2.1.0
1. [Ability to Provision Infrastructure for Exadata Cloud Service Deployments](#exadata_2_1_0)
1. [OCI Bastion Service Integration](#bastion_2_1_0)
1. [Individual Security Lists for Subnets](#sec_lists_2_1_0)
1. [Ability to Rename Compartments](#cmp_renaming_2_1_0)
1. [Updates to NSGs and Route Rules Descriptions](#rules_descriptions_update_2_1_0)
1. [Input Variable for SSH Connectivity from On-premises Network](#on_prem_ssh_cidrs_2_1_0)
1. [Updates to Resource Manager Interface](#orm_update_2_1_0)

## <a name="exadata_2_1_0">Ability to Provision Infrastructure for Exadata Cloud Service Deployments</a>
Landing Zone can now provision VCNs, compartment, group and policies for Exadata Cloud Service (ExaCS) deployments. The provisioned resources are deployed in tandem with the overall Landing Zone configuration. VCNs are provisioned with client and backup subnets. If a Hub & Spoke network architecture is being deployed, the ExaCS VCNs are configured as spoke VCNs. A compartment is by default created for the ExaCS infrastructure and an extra group and policies are configured accordingly. Optionally, users may opt for deploying ExaCS infrastructure in the database compartment with appropriate permissions granted to database administrators.

## <a name="bastion_2_1_0">OCI Bastion Service Integration</a>
Customers can now leverage OCI Bastion Service in Landing Zone. A Bastion resource is provisioned into a VCN if a single VCN or a single ExaCS VCN is being deployed. Customers can later on create a Bastion session using the provisioned Bastion resource. The Bastion resource is not provisioned for Hub & Spoke architecture or if the Landing Zone VCNs are connected to an on-premises network. In these cases, SSH inbound access is expected to be provided by Bastion servers in the DMZ (Hub) or hosts in the on-premises network.

## <a name="sec_lists_2_1_0">Individual Security Lists for Subnets</a>
Individual security lists are now created for all subnets. This is useful for customers planning on deploying services that require Security Lists instead of Network Security Groups.

## <a name="cmp_renaming_2_1_0">Ability to Rename Compartments</a>
Landing Zone creates compartments with auto-generated names, prefixed by the service_label variable value. Landing Zone compartments can be renamed at any point in time with all policies adjusted accordingly. 

## <a name="rules_descriptions_update_2_1_0">Updates to NSGs and Route Rules Descriptions</a>
The descriptions of rules in NSGs and route tables have been updated aiming at more clarity and verbiage standardization.

## <a name="on_prem_ssh_cidrs_2_1_0">Input Variable for SSH Connectivity from On-premises Network</a>
Variable *onprem_src_ssh_cidrs* is introduced. It is a list of on-premises CIDR blocks allowed to connect to Landing Zone over SSH. It is added to network security rules for ingress connectivity to Landing Zone networks. The *on_prem_ssh_cidrs* must be a subset of the *onprem_cidrs* variable, which are used for routing between on-premises and Landing Zone networks.

## <a name="orm_update_2_1_0">Updates to Resource Manager Interface</a>
With the introduction of Exadata Cloud Service support, Landing Zone schema.yaml has been updated for better usability in OCI Resource Manager. A new variable group named 'Connectivity' has been introduced, containing variables for defining properties that control the sources and destinations for Landing Zone connectivity. 


# August 12, 2021 Release Notes - Stable 2.0.3
1. [Ability to use existing Dynamic Routing Gateway (DRG) v2 with the Landing Zone](#existing_drg_2_0_3)
1. [Consolidated Network and IAM Notifications](#notifications_consolidation_2_0_3)
1. [Database Customer Managed Key Support](#database_key_support_2_0_3)
1. [Compliance Checking supports free tier tenancy](#cis_report_update_2_0_3)


## <a name="existing_drg_2_0_3"></a>1. Ability to use existing Dynamic Routing Gateway (DRG) with the Landing Zone
Customers that have an existing DRG v2 (a DRG created after April 15, 2021) can now use that existing DRG v2 instead of having the Landing Zone create a new DRG v2. This is useful for customers that have connected a FastConnect to an existing DRG.

## <a name="notifications_consolidation_2_0_3"></a>2. Consolidated Network and IAM Notifications
In previous versions of the Landing Zone notification event rules were created for each CIS benchmark monitoring recommendation.  To help reduce the number of event rules created all the IAM recommendations are combined into a single event rule and all the network recommendations are combined into another event rule. 

## <a name="database_key_support_2_0_3"></a>3. Autonomous Database Customer Managed Key Support
Database Administrators now have the ability to use keys from OCI Vaults in the security compartment to encrypt databases in the database compartment.

## <a name="cis_report_update_2_0_3"></a>4. Compliance Checking supports free tier tenancy
Compliance Checking script can now be run free tier OCI tenancy.

# July 2021 Release Notes - Stable 2.0.0
1. [Ability to provision the Landing Zone with narrower permissions](#narrower_permissions)
1. [Ability to provision Landing Zone within an enclosing compartment at any level in the compartment hierarchy](#enclosing_compartment)
1. [Ability to reuse existing groups when provisioning the Landing Zone](#existing_groups)
1. [Hub and Spoke Network Architecture plus networking enhancements](#hub_spoke_network)


## <a name="narrower_permissions"></a>1. Ability to provision the Landing Zone with narrower permissions
Before this release, the Landing Zone required a user with wide permissions in the tenancy in order to be provisioned. Typically, but not necessarily, this user was a member of the *Administrators* group. That has changed. Now the Landing Zone can be provisioned by a user with narrower permissions. However, some pre-requisites need to be satisfied. Specifically, the Landing Zone requires policies created at the tenancy level and broad permissions at the compartment where it is going to be provisioned. 

The Landing Zone handles these requirements with a new Terraform root module that's expected to be executed by a user with wide permissions (typically a member of the *Administrators* group). The module is available in the *pre-config* folder and provisions the following:
	
1. An enclosing compartment for the Landing Zone compartments. 
2. Optionally, a group with the required permissions to provision the Landing Zone in the enclosing compartment.
3. Optionally, Landing Zone required groups for segregation of duties. These groups can then simply be reused when provisioning the Landing Zone.
4. Optionally, required permissions at the tenancy level granted to Landing Zone groups, like permissions granted to Security and IAM administrators.

The variables controlling the pre-config module behavior are described in [Pre-Config Module Variables section](VARIABLES.md#pre_config_input_variables).
	
## <a name="enclosing_compartment"></a>2. Ability to provision Landing Zone within an enclosing compartment at any level in the compartment hierarchy
This can be done by a *wide-permissioned* user or a *narrower-permissioned* user. If done by the *wide-permissioned* user, the steps described in the previous section MUST be skipped. If done by a *narrower-permissioned* user, the steps in the previous section are required. **A _narrower-permissioned_ user is only allowed to provision the Landing Zone in a enclosing compartment previously designated by a _wide-permissioned_ user.**
	
The existing Landing Zone config module has been extended to support this use case. The module keeps backwards compatibility, i.e., the new variables default values keeps the module current behavior unchanged. In other words, if you execute the config module as-is, the four Landing Zone compartments are created directly under the root compartment with all policies created at the root compartment. 

The module behavior is controlled by variables described in the [Enclosing Compartment Variables section](VARIABLES.md#enc_cmp_variables).
	
## <a name="existing_groups"></a>3. Ability to reuse existing groups when provisioning the Landing Zone
Previously, every Landing Zone execution would create groups. However, it's acknowledged that a customer may want to create multiple Landing Zones but only one set of groups, reusing them across the Landing Zones. 

The module behavior is controlled by variables described in the [Existing Groups Reuse Variables section](VARIABLES.md#existing_groups_variables).

## <a name="hub_spoke_network"></a>4. Hub and Spoke Network Architecture plus networking enhancements

Before this release, the Landing Zone would deploy a single VCN with three subnets designed for a 3-tier application with DRG if on-premises connectivity was required.  In this new release we enhanced the networking and network security modules to can support the creation of multiple VCNs (spokes or stand-alone) and the following Hub and Spoke network architectures:
- **Access to multiple VCNs in the same region:** This scenario enables communication between an on-premises network and multiple VCNs in the same region over a single FastConnect private virtual circuit or Site-to-Site VPN and uses a DRG as the hub.
- **Access between multiple networks through a single DRG with a firewall between networks:** This scenario connects several VCNs to a single DRG, with all routing configured to send packets through a firewall in a hub VCN before they can be sent to another network.

In addition to the above architectures, you can choose if want to allow the creation of Internet Gateways and NAT Gateways to provide a more isolated network. Lastly, we have also added support for various network variables to take lists of CIDR ranges instead of a single CIDR. 

The module behavior is controlled by variables described in the [Networking Variables section](VARIABLES.md#networking-variables).


# June 2021 Release Notes - Stable 1.1.1
1. [Logging Consolidation with Service Connector Hub](#logging_consolidation)
1. [Vulnerability Scanning](#vulnerability_scanning)

	
## <a name="logging_consolidations"></a>1. Logging Consolidation with Service Connector Hub
The Landing Zone enables/collects logs for a few services, like VCN and Audit services. From a governance perspective, it's interesting that these logs get consolidated and made available to security management tools. This capability is now availabe in the Landing Zone with the Service Connector Hub, that reads logs from different sources and sends them to a target that the user chooses. By default, this target is a bucket in the Object Storage service, but functions and streams can also be configured as targets. As the usage of a bucket, function or stream may incur in costs to our customers, Landing Zone users must explicitly activate Service Connector Hub by setting variables in the Terraform configuration, as described in [Logging Variables](terraform.md#logging_variables) section.

To delete or change a Service Connector that has an Object Storage bucket as a target, you must manually remove the target from the Service Connector and manually delete the bucket. A bucket with objects cannot be deleted via Terraform.

## <a name="vulnerability_scanning"></a>2. Vulnerability Scanning
The Landing Zone now enables scanning through the Vulnerability Scanning Service (VSS), creating a scan recipe and scan targets by default. The recipe is set to run every week on sundays and the targets are set to all four Landing Zone compartments. Running the Landing Zone as is, weekly scans are automatically executed for any instances deployed in any of the Landing Zone compartments. The scan results are made available in the Security compartment and can be verified in the OCI Console. 

Scanning can be disabled in the Landing Zone, and the scan frequency and targets can be changed as well. Disabling scanning and changing the frequency are controlled by setting variables in the Terraform configuration, as described in [Scanning Variables](terraform.md#vss_variables) section, while targets can be changed in the vss.tf file. The Vulnerability Scanning Service is free.
